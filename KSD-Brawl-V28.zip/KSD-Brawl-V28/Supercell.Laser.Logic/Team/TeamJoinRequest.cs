﻿namespace Supercell.Laser.Logic.Team
{
    using Supercell.Laser.Titan.DataStream;

    public class TeamJoinRequest
    {
        public void Encode(ByteStream stream)
        {
            throw new NotImplementedException();
        }
    }
}
